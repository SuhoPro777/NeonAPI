from setuptools import setup, find_packages

setup(
    name="neonapi",
    version="0.0.1",
    description="NeonAPI - API interaction and management library.",
    author="Neon Team",
    author_email="dev@neonlib.ai",
    packages=find_packages(),
    python_requires=">=3.8",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)
